/*------------
Round Circle Buttons
--------------

Working in IE 10+ and other modern browsers.
Kind of works in IE9 but has some flickering.

Still a work in progress.

*/