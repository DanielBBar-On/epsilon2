A Pen created at CodePen.io. You can find this one at https://codepen.io/wallaceerick/pen/fEdrz.

 A custom file upload with jQuery and CSS.